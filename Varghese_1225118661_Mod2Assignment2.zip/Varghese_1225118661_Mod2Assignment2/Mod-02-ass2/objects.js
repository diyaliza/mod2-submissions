var students = ['John', 'Sammy', 'Jaime', 'Mike', 'Jane']

var grades = [90,99,87,34,76]
 console.log(grades.length)
 console.log(grades[grades.length - 1])
 console.log(grades[grades.length - 2])